
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { getFirestore, doc, getDoc, setDoc, updateDoc, collection, addDoc, query, where, orderBy, limit, getDocs, serverTimestamp, runTransaction, deleteDoc } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

export const firebaseConfig={apiKey:"AIzaSyAXtzsTkbgfsaiKzmlEwdDGqIpbzP4FsHQ",authDomain:"cinemora-ai-14d81.firebaseapp.com",projectId:"cinemora-ai-14d81"};
export const app=initializeApp(firebaseConfig); export const auth=getAuth(app); export const db=getFirestore(app);
export const ADMIN_EMAIL="rjsaid49@gmail.com";
export function qs(s,r=document){return r.querySelector(s)} export function qsa(s,r=document){return [...r.querySelectorAll(s)]}
export function setNotice(el,msg,type="success"){if(!el)return;el.textContent=msg;el.className=`notice show ${type}`}
export function clearNotice(el){if(el){el.textContent="";el.className="notice"}}
export async function getUserDoc(user){const ref=doc(db,"users",user.uid);const snap=await getDoc(ref);if(!snap.exists()){const data={uid:user.uid,email:user.email||"",fullName:user.displayName||"",credits:850,plan:"Free",createdAt:serverTimestamp()};await setDoc(ref,data);return data}return snap.data()}
export async function syncCredits(user){const d=await getUserDoc(user);const c=Number(d.credits??0);localStorage.setItem("cinemora_credits",String(c));return c}
export function formatDate(v){if(!v)return "—";try{const d=v.toDate?v.toDate():new Date(v);return d.toLocaleString()}catch{return "—"}}
export async function requireAuth({redirect="./login.html"}={}){return new Promise((resolve)=>{let done=false;const unsub=onAuthStateChanged(auth,async user=>{if(done)return;done=true;unsub();if(!user){location.href=redirect;return}try{await syncCredits(user)}catch(e){console.error(e)}resolve(user)})})}
export async function logout(){try{await signOut(auth)}finally{location.href="./login.html"}}
export function bindLogout(){qsa("[data-action='logout']").forEach(b=>b.addEventListener("click",logout))}
export function nav(active){const items=[['home','./index.html','⌂','Home'],['templates','./index.html#styles','▱','Templates'],['library','./my-videos.html','▣','Library'],['profile','./settings.html','◉','Profile']];const n=document.createElement("nav");n.className="bottom-nav";n.innerHTML=items.map(([id,href,icon,label])=>`<a class="nav-item ${active===id?'active':''}" href="${href}"><div class="nav-icon">${icon}</div><div>${label}</div></a>`).join("");document.body.appendChild(n)}
export async function createGeneration(user,prompt,style){const userRef=doc(db,"users",user.uid);let newCredits;await runTransaction(db,async tx=>{const snap=await tx.get(userRef);const credits=Number(snap.exists()?snap.data().credits??0:0);if(credits<1)throw new Error("INSUFFICIENT_CREDITS");newCredits=credits-1;tx.set(userRef,{uid:user.uid,email:user.email||"",fullName:user.displayName||"",credits:newCredits,plan:snap.data()?.plan||"Free",updatedAt:serverTimestamp()},{merge:true})});const job=await addDoc(collection(db,"generationJobs"),{uid:user.uid,email:user.email||"",prompt,style,status:"queued",createdAt:serverTimestamp(),updatedAt:serverTimestamp()});localStorage.setItem("cinemora_credits",String(newCredits));return {id:job.id,credits:newCredits,status:"queued"}}
export async function listUserJobs(user,max=20){const ref=query(collection(db,"generationJobs"),where("uid","==",user.uid),limit(max));const snap=await getDocs(ref);return snap.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>{const av=a.createdAt?.toMillis?a.createdAt.toMillis():0;const bv=b.createdAt?.toMillis?b.createdAt.toMillis():0;return bv-av})}
export async function getAdminRows(name,max=100){const snap=await getDocs(query(collection(db,name),limit(max)));return snap.docs.map(d=>({id:d.id,...d.data()}))}
export async function ensureSettings(user){const ref=doc(db,"users",user.uid);const d=await getUserDoc(user);if(!d.settings){const settings={quality4k:false,watermark:true,alerts:true,dailyCredits:true};await updateDoc(ref,{settings});d.settings=settings}return d}
export async function saveSettings(user,settings){await updateDoc(doc(db,"users",user.uid),{settings,updatedAt:serverTimestamp()})}
export async function submitPayment(user,credits,amount,email,reference){return addDoc(collection(db,"payments"),{uid:user.uid,email:email||user.email||"",credits,amount,reference,status:"pending",createdAt:serverTimestamp()})}
if("serviceWorker" in navigator)navigator.serviceWorker.register("./sw.js").catch(()=>{});
